(function(ng) {
    "use strict";
    
    ng.module("shared").factory("AjaxService", [ "$http", "$q", function($http, $q) { 
        return {
            "get":      wrap("get"),
            "post":     wrap("post"),
            "delete":   wrap("delete"),
            "put":      wrap("put")
        };
        
        function wrap(method) {
            var fn = $http[method];
            return function() {
                var deferred = $q.defer();
                fn.apply($http, arguments)
                    .error(deferred.reject)
                    .success(function(result) {
                        return result && result.success
                            ? deferred.resolve(result.data)
                            : deferred.reject(result && result.errors ? result.errors : null);
                    });
                
                return deferred.promise;
            };
        }
    }]);
}(angular));
(function(ng) {
    "use strict";
    
    ng.module("shared").factory("$httpq", ["$http", "$q", function ($http, $q) {
        return {
            "get":      wrap("get"),
            "post":     wrap("post"),
            "delete":   wrap("delete"),
            "put":      wrap("put")
        };
        
        function wrap(method) {
            var fn = $http[method];
            return function () {
                var deferred = $q.defer();
                fn.apply($http, arguments)
                    .success(deferred.resolve)
                    .error(deferred.reject);
                return deferred.promise;
            }
        };
    }]);
}(angular));

(function(ng) {
    "use strict";
    
    ng.module("shared").factory("ValidationService", function() {
        return {
            validate: function(form) {
                var valid = true;
                for(var key in form) {
                    if (form.hasOwnProperty(key) && key[0] !== "$") {
                        form[key].$dirty = true;
                        valid = valid && !form[key].$invalid;
                    }
                }
                return valid;
            }
        };
    });
}(angular));
(function(ng) {
    "use strict";
    
    ng.module("stash").factory("StashService", [ "AjaxService", function(AjaxService) {
        var StashService = {};
        
        StashService.saveStash = function(id, title, tags, markdown) {
            if (!Array.isArray(tags)) {
                tags = tags.match(/[^\s,]+/g) || [];
            }
            
            var data = {
                title: title,
                tags: tags,
                markdown: markdown
            };
            
            return AjaxService.post(
                "/stash" + (id ? ("/"+encodeURIComponent(id)) : ""), 
                data,
                { headers: { "Content-Type" : "application/json; charset=utf-8" } }
            );
        };
        
        StashService.findStash = function(id) {
            return AjaxService.get("/stash/" + id);  
        };
        
        StashService.searchStashes = function(query) {
            return AjaxService.get("/stash/search/" + encodeURIComponent(query));  
        };
        
        return StashService;
    }]);
}(angular));