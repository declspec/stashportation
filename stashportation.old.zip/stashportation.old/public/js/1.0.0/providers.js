(function(ng) {
    "use strict";
    
    ng.module("shared").provider("LazyLoader", function() {
        var cache = {},
            loadTimeout = 5000;
                        
        this.setLoadTimeout = function(timeout) {
            loadTimeout = timeout;
        };
        
        this.$get = [ "$q", function($q) {
            return {
                requireJs:  function(url) { 
                    if ("string" === typeof(url))
                        return load($q, url, createScript);
                    else if (url.constructor === Array) {
                        return $q.all(url.map(function(u) { 
                            return load($q, u, createScript); 
                        }));
                    }
                },
                requireCss: function(url) { 
                    if ("string" === typeof(url))
                        return load($q, url, createStylesheet);
                    else if (url.constructor === Array) {
                        return $q.all(url.map(function(u) { 
                            return load($q, u, createStylesheet); 
                        }));
                    }
                }
            };
        }];
    
        function createScript(url) {
            return ng.extend(document.createElement("script"), {
                src: url,
                async: false
            });
        }
        
        function createStylesheet(url) {
            return ng.extend(document.createElement("link"), {
                rel: "stylesheet",
                type: "text/css",
                href: url
            });
        }
        
        function load($q, url, createElement) {
            if (cache.hasOwnProperty(url))
                return $q.when(cache[url]);
                
            var deferred = $q.defer(),
                done = false,
                element = createElement(url),
                head = document.getElementsByTagName("head")[0];
                
            element.onload = element.onreadystatechanged = function() {
                if (done || (this.readyState && this.readyState !== "loaded" && this.readyState !== "complete"))
                    return;
                
                done = true;
                element.onload = element.onreadystatechanged = null;
                cache[url] = true;
                deferred.resolve();
            };
            
            head.appendChild(element);
            
            setTimeout(function() {
                if (!done) {
                    done = true;
                    element.onload = element.onreadystatechanged = null;
                    ng.element(element).remove();
                    delete cache[url];
                    deferred.reject();
                }
            }, loadTimeout);
            
            return cache[url] = deferred.promise;
        }
    });
}(angular));
(function(ng) {
    "use strict";
    
    $OpaProvider.$inject = [ "$stateProvider", "$injector" ];
    ng.module("shared").provider("$opa", $OpaProvider); 
    
    function $OpaProvider($stateProvider, $injector) {
        var passiveAuth,
            activeAuth;
            
        var states = {};
            
        this.setPassiveAuthentication = function(passive) {
            passiveAuth = passive;
        };
        
        this.setActiveAuthentication = function(active) {
            activeAuth = active;
        };
        
        this.state = function(name, def) {
            if ("object" === typeof(name))
                patch(name)
            else {
                states[name] = def;
                inherit(name, def);
                patch(def);
            }
            
            $stateProvider.state(name, def);
            return this;
        };
        
        // This should only be used during configuration steps,
        // there is no concrete service
        this.$get = function() { return {}; };
        
        function patch(def) {
            if (def.abstract === true)
                return;
            
            var authenticate = def.authenticate !== false,
                resolver = null;
            
            if (activeAuth || passiveAuth) {
                if (authenticate || passiveAuth) {
                    resolver = { auth: (authenticate && activeAuth ? $active : passiveAuth) };
                }
            } 

            if (def.javascript || def.css) {
                resolver = resolver || {};
                resolver.dependencies = createResolver(def.javascript, def.css);
            }
            
            if (resolver !== null) {
                def.resolve = !def.hasOwnProperty("resolve")
                    ? resolver
                    : ng.extend(resolver, def.resolve);
            }
        }
        
        function inherit(name, def) {
            var offset = 0,
                parent = name,
                state = null;
            
            // Traverse up the chain and inherit properties
            while((offset = parent.lastIndexOf(".")) > 0) {
                parent = parent.substring(0, offset);
                state = states[parent];
                
                if ("undefined" !== typeof(state)) {
                    def.javascript = merge(def.javascript, state.javascript);
                    def.css = merge(def.css, state.css);
                    
                    if (state.hasOwnProperty("authenticate") && !def.hasOwnProperty("authenticate")) 
                        def.authenticate = state.authenticate;
                    
                    if (state.hasOwnProperty("async") && !def.hasOwnProperty("async"))
                        def.async = state.async;
                }
            }
        }
        
        function merge(a1, a2) {
            if ("undefined" === typeof(a1) || a1 === null)
                return a2;
            else if ("undefined" === typeof(a2) || a2 === null)
                return a1;
            else if ("string" === typeof(a1)) {
                return a2.constructor === Array
                    ? (a2.push(a1) && a2)
                    : [ a1, a2 ];
            }
            else if ("string" === typeof(a2)) {
                return a1.constructor === Array
                    ? (a1.push(a2) && a1)
                    : [ a1, a2 ]
            }
        }
        
        function createResolver(js, css) {
            var resolver = function(LazyLoader) {
                if (css)
                    LazyLoader.requireCss(css);
                return js ? LazyLoader.requireJs(js) : true;
            };
            
            resolver.$inject = [ "LazyLoader" ];
            return resolver;
        }
        
        $active.$inject = [ "$q" ];
        function $active($q) {
            if (!passiveAuth) {
                return $q.when($injector.invoke(activeAuth)).then(function(success) { 
                    return success || $q.reject(); 
                });
            }
            else {
                // Chain with passive authentication
                return $q.when($injector.invoke(passiveAuth)).then(function(success) {
                    return success 
                        ? success
                        : $q.when($injector.invoke(activeAuth)).then(function(success) { return success || $q.reject(); });
                });
            }
        }
    }   
}(angular))