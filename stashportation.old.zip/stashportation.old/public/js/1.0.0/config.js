(function(ng) {
    "use strict";
    
    ng.module("shared", [ "ui.router" ]);
}(angular));
(function(ng) {
    "use strict";
    
    var stash = ng.module("stash", [ "shared", "modalDialog" ]);
    
    stash.config(["$opaProvider", "$urlRouterProvider", "$modalDialogProvider", 
        function($opaProvider, $urlRouterProvider, $modalDialogProvider) {
            $urlRouterProvider.otherwise("/");
            
            $opaProvider.state("search", {
                url: "/search/:query",
                templateUrl: "partials/stash/search.html",
                controller: "SearchController"
            })
            .state("edit", {
                url: "/:id",
                templateUrl: "partials/stash/edit.html",
                controller: "EditStashController",
                reloadOnSearch: false,
                javascript: [
                    "//cdnjs.cloudflare.com/ajax/libs/markdown-it/4.3.1/markdown-it.min.js",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/codemirror.min.js",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/addon/mode/overlay.min.js",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/mode/xml/xml.min.js",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/mode/markdown/markdown.min.js",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/mode/gfm/gfm.min.js"
                ],
                css: [
                    "/css/stash.css",
                    "//cdnjs.cloudflare.com/ajax/libs/codemirror/5.4.0/codemirror.min.css"
                ]
            })
            
            
            $modalDialogProvider.register("tag-dialog", {
                templateUrl: "partials/stash/_tag-dialog.html",
                cancelable: true,
                controller: [ "$scope", "$modalDialogParams", "DialogResult", function($scope, $modalDialogParams, DialogResult) {
                    $scope.tags = $modalDialogParams.tags || "";
                    $scope.save = function() {
                        $scope.close(DialogResult.Success, $scope.tags);   
                    };
                }]
            });
        }
    ]);
}(angular));
(function(ng) {
    "use strict";
    
    var app = ng.module("stashportation", [ "shared", "stash", "modalDialog" ]);
    
    app.run(["$rootScope", function($rootScope) {
        $rootScope.APP_TITLE = "Stashportation";
        $rootScope.APP_VERSION = "1.0.0";
        $rootScope.PAGE_TITLE = "Untitled";
        
        $rootScope.$on("$stateChangeSuccess", function(event, toState) {
            if (toState.title) 
                $rootScope.PAGE_TITLE = toState.title;
        });
    }]);
}(angular));