<?php
class StrongClass {
    public function _get() {
        return "foo";
    }
};


$cls = new stdClass();
$cls->_get = "factory";

$inst = new StrongClass();

echo property_exists($cls, "_get") ? "Y" : "N";
echo "\n";
echo property_exists($inst, "_get") ? "Y" : "N";
