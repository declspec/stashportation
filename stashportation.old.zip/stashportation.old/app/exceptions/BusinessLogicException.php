<?php
class BusinessLogicException extends Exception {
    private $_friendlyError;
    
    public function __construct($friendlyError, $extendedMessage = null, $code = 0, Exception $inner = null) {
        if ($extendedMessage === null)
            $extendedMessage = $friendlyError;
        
        parent::__construct($extendedMessage, $code, $previous);
    }
    
    public function getFriendlyMessage() {
        return $this->_friendlyError;   
    }
};
