<?php
return array(
    "defaultController" => "home",
    "autoEscapeHtml" => FALSE,
    "debugLevel" => 2,
    
    // configuration items that are accessible anywhere in the application
    "settings" => array(
    ),

    "routes" => array(
        "POST /stash/@id" =>  array("controller" => "Stash", "action" => "save"),
        "POST /stash" =>      array("controller" => "Stash", "action" => "save"),
        "GET  /stash/@id" =>  array("controller" => "Stash", "action" => "find"),
        "GET  /stash/search/@q" => array("controller" => "Stash", "action" => "search")
    ),
    
    // Core config
    "db" => array(
        "connectionString"  => $secret["db"]["connectionString"],
        "username"          => $secret["db"]["username"],
        "password"          => $secret["db"]["password"]
    ),
    "session" => array(
        "timeout" => 20,
        "autoExpire" => true
    ),
    "modules" => array(
        "core",
        "services",
        "controllers",
        "routes"
    ),
);
