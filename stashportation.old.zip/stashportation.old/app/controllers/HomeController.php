<?php
class HomeController {
    public function __construct() {
    }   
    
    public function index($app) {
        echo "<h1>Welcome to WireFrame</h1>";
    }
};