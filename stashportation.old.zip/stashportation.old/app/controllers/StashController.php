<?php
require("viewmodels/StashViewModel.php");
require("transformers/StashTransformer.php");
require("AjaxController.php");

class StashController extends AjaxController {
    private $_stashViewModelProvider;
    private $_stashTransformer;
    private $_stashService;
    
    public function __construct($validatorFactory, $stashService) {
        $this->_stashViewModelProvider = new StashViewModelProvider($validatorFactory);
        $this->_stashTransformer = new StashTransformer($this->_stashViewModelProvider);
        $this->_stashService = $stashService;
    }   
    
    public function save($app, $params) { 
        $vm = $this->_stashViewModelProvider->bind($_POST);
        // Manually set the ID from the url (if present)
        if (isset($params["id"]))
            $vm->set("id", $params["id"]);
        
        // Validate the ViewModel
        if (!$vm->validate())
            return $this->handleInvalidModel($vm);
        
        // Transform the valid ViewModel into a Model to give to the service.
        $model = $this->_stashTransformer->toModel($vm);
        $result = $this->performAction($model, array($this->_stashService, "save"));
        
        if ($result !== false) {
            $serialized = $this->_stashTransformer->toViewModel($result)->serialize();
            return $this->ajaxify(true, $serialized);
        }
    }
    
    public function find($app, $params) {
        if (!isset($params["id"]) || intval($params["id"]) === 0)
            return $app->error(404);
        
        $stash = $this->performAction($params["id"], array($this->_stashService, "findById"));
        if ($stash !== false) {
            $serialized = $this->_stashTransformer->toViewModel($stash)->serialize();
            return $this->ajaxify(true, $serialized);
        }
    }
    
    public function search($app, $params) {
        $data = $this->performAction($params["q"], array($this->_stashService, "search"));
        if ($data !== false) {
            $transformer = $this->_stashTransformer;
            $serialized = array_map(function($stash) use(&$transformer) {
                return $transformer->toViewModel($stash)->serialize();
            }, $data);
            
            return $this->ajaxify(true, $serialized);
        }
    }
};