<?php
require_once(__DIR__ . "/../../models/StashModel.php");
require_once(__DIR__ . "/../../lib/modelr/IModelTransformer.php");
require_once(__DIR__ . "/../../lib/modelr/ViewModelProvider.php");

class StashTransformer implements IModelTransformer {
    private $_viewModelProvider;
    
    public function __construct(IViewModelProvider $provider) {
        if ($provider === null)
            throw new InvalidArgumentException("Parameter cannot be null: \'$provider'");
        
        $this->_viewModelProvider = $provider;   
    }
    
    public function toModel(ViewModel $viewModel) {
        if ($viewModel === null)
            throw new InvalidArgumentException("Parameter cannot be null: \'$viewModel'");
        
        return new StashModel(
            $viewModel->get("id"),
            $viewModel->get("title"), 
            $viewModel->get("tags"), 
            $viewModel->get("markdown")
        );
    }
    
    public function toViewModel($model) {
        if ($model === null)
            throw new InvalidArgumentException("Parameter cannot be null: \'$model'");
        
        $vm = $this->_viewModelProvider->create();
        $vm->set("id", $model->getId());
        $vm->set("title", $model->getTitle());
        $vm->set("tags", $model->getTags());
        $vm->set("markdown", $model->getMarkdown());

        return $vm;
    }
}