<?php
require_once(__DIR__ . "/../../lib/modelr/ViewModelProvider.php");

class StashViewModelProvider extends ViewModelProvider {
    public function __construct(IViewModelValidatorFactory $factory) {
        parent::__construct(ViewModelSchema::compile($factory, array(
            "fields" => array(
                "id"        => "id",
                "title"     => "Title",
                "tags"      => "Tags",
                "markdown"  => "Markdown"
            ),
            "rules" => array(
                array(
                    "validator" => "required",
                    "fields" => array("title","tags","markdown")
                ),
                array(
                    "validator" => "length",
                    "fields" => "title",
                    "args" => array("max" => 256)
                ),
                array(
                    "validator" => "integer",
                    "fields" => "id"
                )
            )
        )));
    }
};