<?php
require_once(__DIR__ . "/../exceptions/BusinessLogicException.php");

abstract class Controller {
    
    protected abstract function handleError($exception);
    protected abstract function handleException($exception);

    protected function performAction() {
        $args = func_get_args();
        $callable = array_pop($args);
        
        try {
            return call_user_func_array($callable, $args);
        }
        catch(BusinessLogicException $err) {
            $this->handleError($err);
            return false;
        }
        catch(Exception $ex) {
            $this->handleException($ex);
            return false;
        }
    }
};