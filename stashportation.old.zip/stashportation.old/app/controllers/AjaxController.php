<?php
require_once("Controller.php");

abstract class AjaxController extends Controller {
    public function __construct() {
    
    }
    
    protected function ajaxify($success, $data=null,$errors=array()) {
        header("Content-Type: application/json");
        echo json_encode(array(
            "success" => !!$success,
            "data" => $data,
            "errors" => $errors
        ));
    }
    
    protected function handleInvalidModel($model) {
        return $this->ajaxify(false, null, $model->getErrorSummary());
    }
    
    protected function handleError($error) {
        return $this->ajaxify(false, null, array($error->getFriendlyMessage()));   
    }
    
    protected function handleException($exception) {
        error_log($exception);
        return $this->ajaxify(false, null, array("An unknown error occurred, please try again."));   
    }
};
