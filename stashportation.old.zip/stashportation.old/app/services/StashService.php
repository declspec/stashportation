<?php
require_once(__DIR__ . "/../exceptions/BusinessLogicException.php");

class StashService {
    const STASH_TABLE        = "stash";
    const TAG_TABLE          = "tag";
    const STASH_TAGS_TABLE   = "stash_tags";
    
    private $_dbConnection;
    
    public function __construct($dbConnection) {
        $this->_dbConnection = $dbConnection;
    }
    
    public function save($model) {
        $newRecord = !$model->getId();
        $mappings = array(
            ":title" => $model->getTitle(),
            ":markdown" => $model->getMarkdown()
        );
        
        if (!$newRecord)
            $mappings[":id"] = $model->getId();
        
        // Build the sql
        $sql = $newRecord 
            ? sprintf("INSERT INTO `%s` (title, markdown, date_created) VALUES (:title, :markdown, NOW())", self::STASH_TABLE)
            : sprintf("UPDATE `%s` SET title = :title, markdown = :markdown, date_modified = NOW() WHERE id = :id", self::STASH_TABLE);
        
        // start a transaction
        $this->_dbConnection->begin();
        try {
            $result = $this->_dbConnection->exec($sql, $mappings);

            if ($newRecord) 
                $model->setId($this->_dbConnection->lastInsertId());   
            elseif ($result !== 1) 
                throw new BusinessLogicException("The specified stash does not exist.", "Stash with id `{$model->getId()}` not found");
            else {
                // Remove existing tag mappings
                $this->_dbConnection->exec(
                    sprintf("DELETE FROM `%s` WHERE stash_id = :id", self::STASH_TAGS_TABLE),
                    array(":id" => $model->getId())
                );
            }
            
            // insert the tags
            $tags = $model->getTags();
            $tagSql = sprintf(
                "INSERT IGNORE INTO `%s` (tag,date_created) VALUES %s", 
                self::TAG_TABLE, 
                implode(",", array_fill(0, count($tags), "(?,NOW())"))
            );
            
            $this->_dbConnection->exec($tagSql, $tags);
            
            // create the joins
            $joinSql = sprintf(
                "INSERT INTO `%s` (stash_id, tag_id) SELECT %d, id FROM `%s` WHERE tag IN (%s)",
                self::STASH_TAGS_TABLE,
                intval($model->getId()),
                self::TAG_TABLE,
                implode(",", array_fill(0, count($tags), "?"))
            );
            
            $this->_dbConnection->exec($joinSql, $tags);
            $this->_dbConnection->commit();
            
            return $model;
        }
        catch(Exception $ex) {
            $this->_dbConnection->rollback();
            throw $ex;
        }
    }
    
    public function search($query) {
        $regexp = implode("|", array_map("preg_quote", preg_split("/[,\\s]+/", $query)));
        
        // Currently only supports searching by tags/title
        $sql = sprintf(
            "SELECT sub.id, sub.title, GROUP_CONCAT(t.tag) AS tags
             FROM (
                SELECT s.id, s.title, s.date_created, s.date_modified
                FROM `%s` s 
                INNER JOIN `%s` st2 ON st2.stash_id = s.id 
                INNER JOIN `%s` t2 ON t2.id = st2.tag_id 
                WHERE t2.tag REGEXP :regexp -- no need to lower t2.tag as they're all lowercase
                
                UNION 
                
                SELECT s.id, s.title, s.date_created, s.date_modified
                FROM `%s` s
                WHERE LOWER(s.title) REGEXP :regexp
             ) sub
             INNER JOIN `%s` st ON st.stash_id = sub.id
             INNER JOIN `%s` t ON t.id = st.tag_id
             GROUP BY sub.id",
            self::STASH_TABLE,
            self::STASH_TAGS_TABLE,
            self::TAG_TABLE,
            self::STASH_TABLE,
            self::STASH_TAGS_TABLE,
            self::TAG_TABLE
        );

        $records = $this->_dbConnection->exec($sql, array(":regexp" => strtolower($regexp)));
        return array_map(function($row) {
            return new StashModel($row["id"], $row["title"], explode(",", $row["tags"]), null);
        }, $records);
    }
    
    public function findById($id) {
        $sql = sprintf("SELECT id, title, markdown FROM `%s` WHERE id = ?", self::STASH_TABLE);
        $stash = $this->_dbConnection->execSingle($sql, $id);
        
        if ($stash === null)
            return null;
        
        $tagSql = sprintf(
            "SELECT t.tag FROM `%s` t INNER JOIN `%s` st ON st.tag_id = t.id WHERE st.stash_id = %d",
            self::TAG_TABLE,
            self::STASH_TAGS_TABLE,
            $stash["id"]
        );
        
        $tagRows = $this->_dbConnection->exec($tagSql);
        $tags = array_map(function($t) { return $t["tag"]; }, $tagRows);
        
        return new StashModel($stash["id"], $stash["title"], $tags, $stash["markdown"]);
    }
};