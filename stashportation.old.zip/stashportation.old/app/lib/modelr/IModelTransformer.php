<?php
require_once("ViewModel.php");

interface IModelTransformer {
    function toModel(ViewModel $viewModel);
    function toViewModel($model);
};