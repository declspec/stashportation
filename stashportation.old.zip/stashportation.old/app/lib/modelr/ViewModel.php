<?php
require_once("ViewModelSchema.php");

class ViewModel {
    private $_schema  = null;
    private $_errors    = array();
    private $_values    = array();
    private $_dirty     = false;
    
    public function __construct(ViewModelSchema $schema) {
        if ($schema === null)
            throw new InvalidArgumentException("Parameter cannot be null: '\$schema'");
        
        $this->_schema = $schema;  
        foreach($this->_schema->getFields() as $field) {
            $this->_values[$field->getName()] = $field->getDefaultValue();
        }
    }
    
    public function get($field, $defaultValue=null) {
        return isset($this->_values[$field])
            ? $this->_values[$field]
            : $defaultValue;
    }
    
    public function set($field, $value) {
        if (!$this->has($field))
            throw new OutOfRangeException("Unrecognized field '$field'");
        
        $this->_values[$field] = is_string($value) 
            ? trim($value) 
            : $value;
    }
    
    public function label($field) {
        return $this->has($field)
            ? $this->_schema->getField($field)->getLabel()
            : $field;
    }
    
    public function has($field) {
        return isset($this->_values[$field]) || array_key_exists($field, $this->_values);   
    }
    
    public function serialize() {
        return $this->_values;
    }

    public function addError($field, $message, array $tokens = array()) {
        $label = $this->label($field);
        $tokens["field"] = $label;
        
        $message = preg_replace_callback('/\{\s*([a-z][a-z0-9_]*)\s*\}/i', function($m) use(&$tokens) {
            return isset($tokens[$m[1]]) ? $tokens[$m[1]] : $m[0];
        }, $message);
        
        if (!isset($this->_errors[$field]))
            $this->_errors[$field] = array($message);
        else 
            $this->_errors[$field][] = $message;
        
        $this->_dirty = true;
        return $this;
    }
    
    public function hasErrors($field=null) {
        return $field === null
            ? $this->_dirty
            : isset($this->_errors[$field]);
    }
    
    public function getErrors($field=null) {
        return $field === null
            ? $this->_errors
            : (isset($this->_errors[$field]) ? $this->_errors[$field] : array());
    }
    
    public function getErrorSummary() {
        return $this->_dirty
            ? call_user_func_array("array_merge", array_values($this->_errors))
            : array();
    }
    
    public function clean($field=null) {
        if ($field !== null) {
            unset($this->_errors[$field]);
            $this->_dirty = count($this->_errors) > 0;
        }
        else {
            $this->_errors = array();
            $this->_dirty = false;
        }   
        
        return $this;
    }

    public function validate() {
        $valid = true;
        $fname = "";
        
        foreach($this->_schema->getFields() as $field) {
            $fname = $field->getName();
            foreach($field->getRules() as $rule) {
                $valid = $rule->apply($this, $fname, $this->get($fname)) && $valid;
            }
        }
        
        return $valid;
    }
}