<?php
interface IViewModelValidatorFactory {
    function resolve($validator);
    function register($name, IViewModelValidator $validator);
};

interface IViewModelValidator {
    function validate($model, $field, $value, $args);
};

class ViewModelValidatorFactory implements IViewModelValidatorFactory {
    private static $CORE_VALIDATORS = array(
        "email",
        "required",
        "length",
        "integer",
        "compare"
    );
    
    private $_validators = array();
    
    public function __construct() {
        foreach(self::$CORE_VALIDATORS as $validator) {
            $this->registerCoreValidator($validator);
        }
    }
    
    public function register($name, IViewModelValidator $validator) {
        if ($validator === null)
            throw new InvalidArgumentException("Parameter cannot be null: \'$validator'");
        
        $this->_validators[$name] = $validator;
        return $this;
    }
    
    public function resolve($name) {
        return isset($this->_validators[$name])
            ? $this->_validators[$name]
            : null;
    }
    
    protected function registerCoreValidator($name) {
        $className = ucfirst($name) . "Validator";
        require_once(__DIR__ . "/validators/{$className}.php");
        return $this->register($name, new $className());
    }
};
