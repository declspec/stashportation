<?php
require_once("ViewModelValidator.php");

class ViewModelRule {
    private $_validator;
    private $_arguments;
    
    public function __construct(IViewModelValidator $validator, $arguments) {
        $this->_validator = $validator;
        $this->_arguments = $arguments;
    }
    
    public function apply($model, $field, $value) {
        return $this->_validator->validate($model, $field, $value, $this->_arguments);
    }
};

class ViewModelField {
    private $_name;
    private $_label;
    private $_defaultValue;
    private $_rules;
    
    public function getDefaultValue() { return $this->_defaultValue; }
    public function getName() { return $this->_name; }
    public function getLabel() { return $this->_label; }
    public function getRules() { return $this->_rules; }
    
    public function __construct($name, $label, $defaultValue=null, array $rules=array()) {
        $this->_name = $name;
        $this->_label = $label;
        $this->_defaultValue = $defaultValue;
        $this->_rules = $rules;
    }
    
    public function addRule(ViewModelRule $rule) {
        $this->_rules[] = $rule;
    }
}

class ViewModelSchema {
    private $_fields = array();
    
    public function addField($name, $label, $defaultValue=null) {
        if (!isset($this->_fields[$name]))
            $this->_fields[$name] = new ViewModelField($name, $label, $defaultValue);
    }
    
    public function addRule($fields, IViewModelValidator $validator, $validatorArgs) {
        $rule = new ViewModelRule($validator, $validatorArgs);
        $fields = (array)$fields;
        
        foreach($fields as $field) {
            if (isset($this->_fields[$field]))
                $this->_fields[$field]->addRule($rule);
        }        
    }
    
    public function getField($name) {
        return isset($this->_fields[$name])
            ? $this->_fields[$name]
            : null;
    }
    
    public function getFields() {
        return $this->_fields;   
    }
    
    public static function compile(IViewModelValidatorFactory $validatorFactory, array $config) {
        $schema = new ViewModelSchema();
        
        if (isset($config["fields"])) {
            foreach($config["fields"] as $field=>$attrs) {
                if (!is_array($attrs))
                    $schema->addField($field, $attrs);
                else {
                    $label = isset($attrs["label"]) ? $attrs["label"] : self::labelize($field);
                    $default = isset($attrs["defaultValue"]) ? $attrs["defaultValue"] : null;
                    
                    $schema->addField($field, $label, $default);
                }
            }
        }
        
        if (isset($config["rules"])) {
            foreach($config["rules"] as $rule) {
                $schema->addRule(
                    $rule["fields"], 
                    $validatorFactory->resolve($rule["validator"]), 
                    isset($rule["args"]) ? $rule["args"] : null
                );
            }
        }
        
        return $schema;
    }
    
    protected static function labelize($name) {
        $labelized = preg_replace_callback('/([A-Z]+|[0-9]+)/', function($x) { 
            return ' ' . (is_numeric($x[0][0]) ? $x[0].' ' : $x[0]);
        }, $name);

        return ucfirst($labelized);
    }
};
