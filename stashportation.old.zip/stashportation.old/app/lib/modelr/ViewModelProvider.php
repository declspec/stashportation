<?php
require_once("ViewModel.php");
require_once("ViewModelSchema.php");

interface IViewModelProvider {
    function create();
    function bind($object);
};

class ViewModelProvider implements IViewModelProvider {
    private $_schema;
    private $_vmClass;
    
    public function __construct(ViewModelSchema $schema) { 
        if ($schema === null)
            throw new InvalidArgumentException("Parameter cannot be null: '\$schema'");
        
        $this->_schema = $schema;
    }
    
    public function bind($object) {
        $vm = $this->create();
        $isAssoc = is_array($object);
        
        foreach($this->_schema->getFields() as $field) {
            $fname = $field->getName();
            if ($isAssoc && isset($object[$fname]))
                $vm->set($fname, $object[$fname]);
            elseif (!$isAssoc && isset($object->$fname))
                $vm->set($fname, $object->$fname);
        }
        
        return $vm;
    }
    
    public function create() {
        return new ViewModel($this->_schema);
    }
};

/*
class ViewModelProvider implements IViewModelProvider {
    private $_schema;
    private $_vmClass;
    private $_validatorFactory;
    
    public function __construct($schema, $viewModelClass) {
        if (!($schema instanceof Schema)) 
            throw new InvalidArgumentException("schema must be a valid Schema instance");
        
        $this->_schema = $schema->compile();
        $this->_vmClass = $viewModelClass
        $this->_validatorFactory = new ValidatorFactory();
    }
    
    public function bind($object) {
        $vm = $this->create();
        $isAssoc = is_array($object);
        
        foreach($this->_schema->getFields() as $field=>$attr) {
            if ($isAssoc && isset($object[$field]))
                $vm->set($field, $object[$field]);
            elseif (!$isAssoc && isset($object->$field))
                $vm->set($field, $object->$field);
        }
        
        return $vm;
    }
    
    public function create() {
        $class = $this->_vmClass;
        return new $class($this);
    }
    
    public function validate(Model $model) {
        foreach($this->_schema->getRules() as $rule) {
            $validator = $this->_validatorFactory->resolve($rule["validator"]);
            $args = isset($rule["args"]) ? $rule["args"] : null;
            
            if ($validator === null)
                throw new OutOfRangeException("Validator ${rule['validator']} is not recognized");
            
            if (is_string($rule["fields"]))
                return $this->validateField($model, $rule["fields"], $rule, $validator, $args);
            
            $valid = true;
            foreach($rule["fields"] as $field) {
                $valid = $this->validateField($model, $field, $rule, $validator, $args) && $valid;
            }
            
            return $valid;
        }
    }
    
    private function validateField($model, $field, $rule, $validator, $args) {
        $value = $model->get($field);

        if (!isset($rule["array"]) || !$rule["array"] || !is_array($value))
            return $validator->validate($model, $field, $value, $args);;
        
        $valid = true;
        foreach($value as $subval) {
            $valid = $validator->validate($model, $field, $subval, $args) && $valid;
        }
        
        return $valid;
    }
}*/