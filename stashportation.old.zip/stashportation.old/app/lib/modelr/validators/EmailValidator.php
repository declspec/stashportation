<?php
// Email Validator
class EmailValidator implements IViewModelValidator {
    private static $ERROR_FORMAT = "{field} is not valid email address; please enter a valid email.";
    private static $EMAIL_TEST = '/^[a-z0-9!#$%&\'*+\/=?^_`{|}~-]+(?:(?:[a-z0-9!#$%&\'.*+\/=?^_`{|}~-]|\\@)+)*@[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,}$/i';

    public function validate($model, $field, $value, $args) {
        if (!empty($value) && preg_match(self::$EMAIL_TEST, $value)) {
            $model->addError($field, self::$ERROR_FORMAT);
            return false;
        }
        return true;
    }
};
