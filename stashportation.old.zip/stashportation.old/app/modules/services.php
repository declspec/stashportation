<?php
class ServicesModule implements IModule {
    public function build($app, $config, $ioc) {
        // Register services here
        $ioc->singleton("StashService", function($c) {
            require(__DIR__ . "/../services/StashService.php");
            return new StashService($c->resolve("DatabaseConnection"));
        });
    }
};