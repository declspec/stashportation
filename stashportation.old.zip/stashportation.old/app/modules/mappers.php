<?php
class MappersModule implements IModule {
    /**
     * @param $app
     * @param $config
     * @param $ioc
     */
    public function build($app, $config, $ioc) {
        // Build your data mappers here
    }
};