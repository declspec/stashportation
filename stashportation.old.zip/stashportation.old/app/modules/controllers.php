<?php
class ControllersModule implements IModule {
    public function build($app, $config, $ioc) {
        $ioc->singleton("ViewModelFactory", function() {
            require_once(__DIR__ . "/../lib/modelr/ViewModelValidator.php");
            return new ViewModelValidatorFactory();
        })
        ->singleton("HomeController", function() {
            require(__DIR__ . "/../controllers/HomeController.php");
            return new HomeController();
        })
        ->singleton("StashController", function($c) {
            require(__DIR__ . "/../controllers/StashController.php");
            return new StashController($c->resolve("ViewModelFactory"), $c->resolve("StashService"));
        });
    }
};