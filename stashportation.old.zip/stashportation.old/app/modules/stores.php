<?php
class StoresModule {
    public function build($app, $config, $ioc) {
        // Register persistent stores here
    }
};
