<?php
class StashModel {
    private $_id;
    private $_title;
    private $_tags;
    private $_markdown;
    
    public function getId() { return $this->_id; }
    public function getTitle() { return $this->_title; }
    public function getTags() { return array_keys($this->_tags); }
    public function getMarkdown() { return $this->_markdown; }
    
    public function __construct($id, $title, array $tags, $markdown) {
        $this->_id = $id;
        $this->_title = $title;
        $this->_markdown = $markdown;
        $this->_tags = array();
        
        if ($tags !== null) {
            foreach($tags as $tag)
                $this->addTag($tag);
        }
    }
    
    public function addTag($tag) {
        $tag = strtolower($tag);
        $this->_tags[$tag] = true;
    }
    
    public function setId($id) {
        $this->_id = $id;   
    }
};