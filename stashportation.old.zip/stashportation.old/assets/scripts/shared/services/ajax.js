(function(ng) {
    "use strict";
    
    ng.module("shared").factory("AjaxService", [ "$http", "$q", function($http, $q) { 
        return {
            "get":      wrap("get"),
            "post":     wrap("post"),
            "delete":   wrap("delete"),
            "put":      wrap("put")
        };
        
        function wrap(method) {
            var fn = $http[method];
            return function() {
                var deferred = $q.defer();
                fn.apply($http, arguments)
                    .error(deferred.reject)
                    .success(function(result) {
                        return result && result.success
                            ? deferred.resolve(result.data)
                            : deferred.reject(result && result.errors ? result.errors : null);
                    });
                
                return deferred.promise;
            };
        }
    }]);
}(angular));