(function(ng) {
    "use strict";
    
    ng.module("shared").factory("$httpq", ["$http", "$q", function ($http, $q) {
        return {
            "get":      wrap("get"),
            "post":     wrap("post"),
            "delete":   wrap("delete"),
            "put":      wrap("put")
        };
        
        function wrap(method) {
            var fn = $http[method];
            return function () {
                var deferred = $q.defer();
                fn.apply($http, arguments)
                    .success(deferred.resolve)
                    .error(deferred.reject);
                return deferred.promise;
            }
        };
    }]);
}(angular));
