(function(ng) {
    "use strict";
    
    ng.module("shared", [ "ui.router" ]);
}(angular));