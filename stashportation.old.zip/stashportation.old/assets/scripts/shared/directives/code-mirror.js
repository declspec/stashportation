angular.module("shared").directive("codeMirror", function() {
    "use strict";
    
    return {
        require: "ngModel",
        link: function(scope, element, attrs, ngModel) {
            var options = attrs["codeMirrorOpts"],
                config = options && scope[options] || {};

            var editor = CodeMirror(element[0], config);
            editor.on("changes", update);

            ngModel.$render = function() {
                editor.setValue(ngModel.$viewValue || "");
            };

            scope.$on("$destroy", function() {
                editor.off("changes", update);
            });
            
            scope.$on("editorOptionChanged", function(e, opt, val) {
                editor.setOption(opt, val); 
            });

            function update() {
                ngModel.$setViewValue(editor.getValue());
            }
        }
    }
});