angular.module("shared").directive("markdownPreview", function() {
    "use strict";
    
    return {
        scope: { markdownOpts: "=" },
        link: function(scope, element, attrs) {
            var md = markdownit(scope.markdownOpts || {});
            
            scope.$on("markdownChanged", function(e, markdown) {
                element.html(markdown ? md.render(markdown) : "");
                scope.$emit("markdownPreviewChanged");
            });
        }
    }
});