(function(ng) {
    "use strict";
    
    ng.module("shared").provider("LazyLoader", function() {
        var cache = {},
            loadTimeout = 5000;
                        
        this.setLoadTimeout = function(timeout) {
            loadTimeout = timeout;
        };
        
        this.$get = [ "$q", function($q) {
            return {
                requireJs:  function(url) { 
                    if ("string" === typeof(url))
                        return load($q, url, createScript);
                    else if (url.constructor === Array) {
                        return $q.all(url.map(function(u) { 
                            return load($q, u, createScript); 
                        }));
                    }
                },
                requireCss: function(url) { 
                    if ("string" === typeof(url))
                        return load($q, url, createStylesheet);
                    else if (url.constructor === Array) {
                        return $q.all(url.map(function(u) { 
                            return load($q, u, createStylesheet); 
                        }));
                    }
                }
            };
        }];
    
        function createScript(url) {
            return ng.extend(document.createElement("script"), {
                src: url,
                async: false
            });
        }
        
        function createStylesheet(url) {
            return ng.extend(document.createElement("link"), {
                rel: "stylesheet",
                type: "text/css",
                href: url
            });
        }
        
        function load($q, url, createElement) {
            if (cache.hasOwnProperty(url))
                return $q.when(cache[url]);
                
            var deferred = $q.defer(),
                done = false,
                element = createElement(url),
                head = document.getElementsByTagName("head")[0];
                
            element.onload = element.onreadystatechanged = function() {
                if (done || (this.readyState && this.readyState !== "loaded" && this.readyState !== "complete"))
                    return;
                
                done = true;
                element.onload = element.onreadystatechanged = null;
                cache[url] = true;
                deferred.resolve();
            };
            
            head.appendChild(element);
            
            setTimeout(function() {
                if (!done) {
                    done = true;
                    element.onload = element.onreadystatechanged = null;
                    ng.element(element).remove();
                    delete cache[url];
                    deferred.reject();
                }
            }, loadTimeout);
            
            return cache[url] = deferred.promise;
        }
    });
}(angular));