(function(ng) {
    "use strict";
    
    ng.module("stash").factory("StashService", [ "AjaxService", function(AjaxService) {
        var StashService = {};
        
        StashService.saveStash = function(id, title, tags, markdown) {
            if (!Array.isArray(tags)) {
                tags = tags.match(/[^\s,]+/g) || [];
            }
            
            var data = {
                title: title,
                tags: tags,
                markdown: markdown
            };
            
            return AjaxService.post(
                "/stash" + (id ? ("/"+encodeURIComponent(id)) : ""), 
                data,
                { headers: { "Content-Type" : "application/json; charset=utf-8" } }
            );
        };
        
        StashService.findStash = function(id) {
            return AjaxService.get("/stash/" + id);  
        };
        
        StashService.searchStashes = function(query) {
            return AjaxService.get("/stash/search/" + encodeURIComponent(query));  
        };
        
        return StashService;
    }]);
}(angular));