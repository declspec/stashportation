(function(ng) {
    "use strict";
    
    // Configure some shorthand overrides
    var langShortcuts = {
        "js": "javascript",
        "html": "xml"
    };
    
    var editorOptions = {
        lineNumbers: true,
        mode: "gfm",
        theme: "github",
        lineWrapping: false
    };
        
    var previewOptions = {
        html: true,
        highlight: function(code, lang) {
            if (langShortcuts.hasOwnProperty(lang))
                lang = langShortcuts[lang];

            if (lang && hljs.getLanguage(lang)) {
                try { return hljs.highlight(lang, code).value; }
                catch(e) { }
            }

            return "";
        }
    };
    
    ng.module("stash").controller("EditStashController", [ "$scope", "$rootScope", "$modalDialog", "$stateParams", "$location", "DialogResult", "StashService", 
        function($scope, $rootScope, $modalDialog, $stateParams, $location, DialogResult, StashService) {
            $scope.stash = {
                id: null,
                title: "Untitled",
                markdown: "",
                tags: ""
            };
            
            $scope.preview = false;
            $scope.editorOptions = editorOptions;
            $scope.previewOptions = previewOptions;
            
            if ($stateParams.id) {
                StashService.findStash($stateParams.id).then(function(stash) {
                    $scope.stash.id = stash.id;
                    $scope.stash.title = stash.title;
                    $scope.stash.markdown = stash.markdown;
                    $scope.stash.tags = stash.tags.join(" ");
                });
            }
            
            $scope.showTagPrompt = function() {
                $modalDialog.show("tag-dialog", { tags: $scope.stash.tags }, function(result, tags) {
                    if (result === DialogResult.Success)
                        $scope.stash.tags = tags;
                });
            };

            $scope.toggle = function(opt) {
                if ($scope.editorOptions.hasOwnProperty(opt))
                    setopt(opt, !$scope.editorOptions[opt]);
                else if ($scope.hasOwnProperty(opt))
                    $scope[opt] = !$scope[opt];
            };
            
            $scope.save = function() {
                StashService.saveStash($scope.stash.id, $scope.stash.title, $scope.stash.tags, $scope.stash.markdown).then(function(stash) {
                    if ($scope.stash.id != stash.id) {
                        // Register a run-once state intercept so that we can change the URL without
                        // reloading the whole controller
                        var off = $scope.$on("$stateChangeStart", function(e) {
                            e.preventDefault();
                            off();
                        });
                        
                        $location.path($location.path() + stash.id);
                    }
                });
            };

            $scope.isActive = function(opt) {
                return $scope.editorOptions.hasOwnProperty(opt)
                    ? !!$scope.editorOptions[opt]
                    : ($scope.hasOwnProperty(opt) ? !!$scope[opt] : false);
            };
            
            $scope.$watch("stash.title", function(n,o) {
                if ("string" === typeof(n)) 
                    $rootScope.PAGE_TITLE = n || "Untitled";
            });

            function setopt(opt, val) {
                if ($scope.editorOptions.hasOwnProperty(opt)) {
                    $scope.editorOptions[opt] = val;
                    $scope.$broadcast("editorOptionChanged", opt, val);
                }
            }
        }
    ]);
}(angular));


