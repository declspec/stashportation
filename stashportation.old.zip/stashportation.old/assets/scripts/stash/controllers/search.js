angular.module("stash").controller("SearchController", [ "$scope", "$stateParams", "StashService",
    function($scope, $stateParams, StashService) {
        $scope.results = null;
        $scope.loading = false;
        $scope.query = $stateParams.query || "";
        
        $scope.search = function() {
            $scope.results = null;
            $scope.loading = true;
            
            StashService.searchStashes($scope.query).then(function(results) {
                $scope.results = results;
            }).finally(function() {
                $scope.loading = false; 
            });
        };
        
        if ($scope.query !== "") {
            $scope.search();   
        }
    }
]);