angular.module("stash").directive("stashPreview", function() {
   "use strict";
    
    return {
        scope: { stash: "=" },
        templateUrl: "partials/stash/_stash-preview.html",
        link: function(element, scope, attrs) {
               
        }
    };
});