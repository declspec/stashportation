angular.module("stash").directive("workbench", [ "$window", function($window) {
    "use strict";
    
    return {
        templateUrl: "partials/stash/_workbench.html",
        scope: {
            editorOpts: "=",
            previewOpts: "=",
            preview: "=",
            model: "=ngModel"
        },
        link: function(scope, element, attrs) {
            var live = false,
                unwatch = null;

            scope.$watch("preview", function(show,old) {
                element[show ? "addClass" : "removeClass"]("show-preview");
                show && broadcast();
            });

            //  Manually fire the onWindowResize to initialize the directive
            onWindowResize();

            // Handle native window resizes
            $window.addEventListener("resize", onWindowResize);
            scope.$on("$destroy", function() {
                $window.removeEventListener("resize", onWindowResize);
            });

            function onWindowResize() {
                // If we're in a small window, the preview screen won't be visible
                // while making changes in the editor, so there's no need to have the
                // live preview update running.
                var update = $window.innerWidth >= 768;

                if (update !== live) {
                    if (!unwatch && update) {
                        unwatch = scope.$watch("model", broadcast);
                        broadcast(); // fire to cause immediate update
                    }
                    else if (!update && unwatch) {
                        unwatch();
                        unwatch = null;
                    }
                    live = update;
                }
            }

            function broadcast() {
                scope.$broadcast("markdownChanged", scope.model);
            }
        }
    }   
}]);