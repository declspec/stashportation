(function(ng) {
    "use strict";
    
    var app = ng.module("stashportation", [ "shared", "stash", "modalDialog" ]);
    
    app.run(["$rootScope", function($rootScope) {
        $rootScope.APP_TITLE = "Stashportation";
        $rootScope.APP_VERSION = "1.0.0";
        $rootScope.PAGE_TITLE = "Untitled";
        
        $rootScope.$on("$stateChangeSuccess", function(event, toState) {
            if (toState.title) 
                $rootScope.PAGE_TITLE = toState.title;
        });
    }]);
}(angular));